#include <cstdlib>
#include <iostream>
#include <string.h>

using namespace std;

int main(int argc, char *argv[])
{
 char nume1[10], nume2[10];
 int lungime,i;
 printf("introd primul cuv ");
 scanf("%s", &nume1);
  printf("introd al doilea cuv ");
 scanf("%s", &nume2);
 lungime=strlen(nume1);
 if (strcmp(nume1,nume2)>0) printf ("sirul %s este mai lung decat sirul %s", nume1, nume2 );
 else printf("sirul %s este mai lung decat sirul %s\n\n", nume2,nume1);
 printf("lungimea este %d \n", lungime);
 printf("primul cuvant scris invers este: ");
 for (i=lungime;i>=0;i--)
     printf("%c",nume1[i]);
 printf("\n\n");
    system("PAUSE");
    return EXIT_SUCCESS;
}
