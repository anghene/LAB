#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
int a[5],i,m;
printf("scrieti numerele:");
scanf("%d",&a[5]);

for(i=0; i<=5 ; i=i+1)
    
    if (a[i]/2==0)
    {
    printf("Numarul %d este par\n" , a[i] );
    }
  
  
  system("PAUSE");	
  return 0;
}
