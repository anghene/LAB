#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) // cel mai mare divizor comun al doua nr.
{

    int x,y,m,i;
    printf("introduceti oricare 2 nr: ");
    scanf("%d,%d",&x,&y);
    if(x>y)
         m=y;
    else
         m=x;

    for(i=m;i>=1;i--){
         if(x%i==0&&y%i==0){
             printf("\n Cel mai mare divizor comun este : %d",i) ;
         }
    }

 
  system("PAUSE");	
  return 0;
}
