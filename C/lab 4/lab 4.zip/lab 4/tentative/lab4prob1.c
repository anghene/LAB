#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) // afisarea tuturor divizorilor unui nr. nat.
{
    int x,m,i;
    printf("introduceti un nr: ");
    scanf("%d",&x);
    for(i=m;i>=1;i--){
         if(x%i==0){
             printf("\n Divizorii lui %d sunt: %d",x,i) ;
         }
    }

system("PAUSE");	
return 0;
}
